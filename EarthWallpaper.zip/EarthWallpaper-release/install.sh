#!/bin/bash
# EarthWallpaper installer — run this after downloading the ZIP

set -e

APP_NAME="EarthWallpaper.app"
ZIP_SRC="$HOME/Downloads/$APP_NAME"
DEST="/Applications/$APP_NAME"

# Step 1: Find the app (look in Downloads if ZIP was extracted there)
if [ ! -d "$ZIP_SRC" ]; then
    # Try current directory
    ZIP_SRC="$(pwd)/$APP_NAME"
fi

if [ ! -d "$ZIP_SRC" ]; then
    echo "找不到 $APP_NAME，请先解压 ZIP 文件到 Downloads 目录。"
    echo "Cannot find $APP_NAME. Please unzip it to your Downloads folder first."
    exit 1
fi

echo "Installing Google Earth Wallpaper..."

# Step 2: Kill existing instance
killall EarthWallpaper 2>/dev/null || true

# Step 3: Copy to Applications
echo "  Copying to /Applications..."
rm -rf "$DEST"
cp -R "$ZIP_SRC" "$DEST"

# Step 4: Remove quarantine flag
echo "  Removing quarantine..."
xattr -cr "$DEST" 2>/dev/null || true

# Step 5: Sign with ad-hoc signature ON THIS MACHINE
echo "  Signing for this machine..."
codesign --force --deep --sign - "$DEST" 2>/dev/null || true

# Step 6: Launch
echo "  Launching..."
open "$DEST"

echo ""
echo "Done! Earth Wallpaper is now running in your menu bar ( )."
echo "安装完成！Earth Wallpaper 已在菜单栏运行 ( )。"
